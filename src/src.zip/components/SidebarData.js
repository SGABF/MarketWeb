import React from 'react';
import * as BsIcons from 'react-icons/bs';
export const SidebarData = [
    {
        title: 'Home',
        path: '/',
        cName: 'nav-text'
    },
    {
        title: '남성의류',
        path: '/Man',
        cName: 'nav-text'
    },
    {
        title: '여성의류',
        path: '/Girl',
        cName: 'nav-text'
    },

    {
        title: '전자기기',
        path: '/Electronics',
        cName: 'nav-text'
    },



];