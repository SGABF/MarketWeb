export default [
  { id: 1, country: "Africa", city: "AmazonBasics", price: "11000" },
  { id: 2, country: "Italy", city: "Venice", price: "2,000,000" },
  { id: 3, country: "Turkey", city: "Cappadocia", price: "3,560,000" },
];


