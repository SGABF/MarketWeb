import React from 'react';

function Food(props) {
    return (
        <div></div>
    );
}


export default Food;