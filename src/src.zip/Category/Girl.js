import React from 'react';

function Girl(props) {
    return (
        <div></div>
    );
}


export default Girl;