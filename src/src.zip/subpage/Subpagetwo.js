import React from "react";

function subpagetwo(props) {
  return (
    <div>
      <h1>ㅇddddddddddddfsdfsdfsdfsdfㅇ</h1>
    </div>
  );
}

export default subpagetwo;

